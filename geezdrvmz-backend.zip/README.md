# Geezdrvmz Beats — Backend

A small Node.js/Express backend so the beat catalog and payment approvals
are shared across every visitor's device, instead of living only in one
browser's `localStorage` (which was the critical bug in the static-file
version — an admin approving a payment on their laptop never showed up
on the buyer's phone).

Now: buyer submits a MoMo transaction ID → it's saved on the server →
admin approves it from anywhere → the buyer's download unlocks the next
time they load the site, on any device.

## What's inside

- `server.js` — the Express app and all API routes
- `db.js` — a tiny JSON-file data store (`data/db.json`), created automatically on first run
- `public/index.html` — the storefront, now talking to the API instead of localStorage
- `scripts/hash-password.js` — generates a bcrypt hash for your admin password
- `uploads/` — where admin-uploaded audio/cover files are saved

No native modules, no external database server required — just Node.js.

## Run it locally

```bash
npm install
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # copy the output
node scripts/hash-password.js yourAdminPassword                            # copy the output
```

Copy `.env.example` to `.env` and fill in the two values above:

```
PORT=3000
JWT_SECRET=<the random string>
ADMIN_PASSWORD_HASH=<the bcrypt hash>
```

Then:

```bash
node server.js
```

Open `http://localhost:3000` — that's the storefront. The admin button
in the header logs in with the password you hashed above.

## How data persists

Beats and orders live in `data/db.json`, written to disk on every
change. Uploaded audio/cover files live in `uploads/`. Both are created
automatically. **Back these up** (or point them at a persistent disk) —
if the server's filesystem is wiped on redeploy, this data goes with it.
Most hosts (see below) let you attach a persistent volume for exactly
this reason.

If the store grows well beyond a personal catalog — many admins,
heavy concurrent traffic — swap `db.js` for a real database
(Postgres, MySQL, etc.). The rest of the app only calls `getData()` /
`saveData()`, so that swap is contained to one file.

## Deploying it for real

You need a host that can keep a Node process running (this is different
from static hosting like GitHub Pages, which won't work for a backend).
Reasonable options for a project this size:

- **Render** (render.com) — free/low-cost web service, supports a
  persistent disk add-on for `data/` and `uploads/`
- **Railway** (railway.app) — similar, simple GitHub-connected deploys
- **Fly.io** — more control, has persistent volumes
- **A basic VPS** (DigitalOcean, Linode, etc.) — run with `pm2` or a
  systemd service so it restarts on crash/reboot

Whichever you pick:
1. Push this folder to a GitHub repo (`.env` is git-ignored — don't commit it)
2. Set `JWT_SECRET` and `ADMIN_PASSWORD_HASH` as environment variables in the host's dashboard, not in a committed file
3. Attach persistent storage for `data/` and `uploads/` if the host offers it, otherwise data is lost on redeploy
4. Point your domain at the host

## Security notes

- The admin password is now checked server-side with bcrypt, and the
  admin dashboard requires a signed session token (JWT) on every
  request — this replaces the old client-side password that anyone
  could read in the page source.
- Rotate `JWT_SECRET` and re-hash your password before going live; the
  values used in local testing should not be reused in production.
- There's no HTTPS built into this server — deploy behind a host that
  terminates TLS for you (all the options above do this automatically).
- Uploaded files aren't scanned or validated beyond file type/size — if
  you expect the public (not just you) to ever submit files, add
  stricter validation.

## API reference

| Method | Route | Auth | Purpose |
|---|---|---|---|
| GET | `/api/beats` | none | list all beats |
| GET | `/api/orders/status?email=` | none | pending/approved status per beat for an email |
| POST | `/api/orders` | none | submit a MoMo transaction ID for verification |
| GET | `/api/download/:beatId?email=` | none (checks approval) | download a beat once approved |
| POST | `/api/admin/login` | none | exchange password for a session token |
| GET | `/api/admin/orders/pending` | admin token | list unverified orders |
| POST | `/api/admin/orders/:id/approve` | admin token | approve an order |
| POST | `/api/admin/orders/:id/reject` | admin token | reject/remove an order |
| POST | `/api/admin/beats` | admin token | add a beat (multipart: file upload or URL fields) |
| DELETE | `/api/admin/beats/:id` | admin token | remove a beat |
