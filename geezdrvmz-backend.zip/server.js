require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { getData, saveData } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;

if (!ADMIN_PASSWORD_HASH) {
  console.warn('\n[WARNING] ADMIN_PASSWORD_HASH is not set in .env — admin login will fail.');
  console.warn('Run: node scripts/hash-password.js yourpassword\n');
}
if (!process.env.JWT_SECRET) {
  console.warn('[WARNING] JWT_SECRET is not set in .env — using an insecure default. Set a real one before deploying.\n');
}

app.use(cors());
app.use(express.json());

// --- File uploads ---
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const safeExt = path.extname(file.originalname).replace(/[^a-zA-Z0-9.]/g, '');
    cb(null, `${Date.now()}-${file.fieldname}${safeExt}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 60 * 1024 * 1024 } }); // 60MB cap

// --- Serve the frontend ---
app.use(express.static(path.join(__dirname, 'public')));

// --- Admin auth middleware ---
function requireAdmin(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing admin token' });
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired admin session, please log in again' });
  }
}

const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// ===================== PUBLIC ROUTES =====================

app.get('/api/beats', (req, res) => {
  res.json(getData().beats);
});

// Given a buyer's email, tell the frontend which beats are pending/approved for them.
app.get('/api/orders/status', (req, res) => {
  const email = (req.query.email || '').toLowerCase().trim();
  if (!email) return res.json({});
  const data = getData();
  const statusMap = {};
  data.orders
    .filter(o => o.email.toLowerCase() === email)
    .forEach(o => {
      if (!statusMap[o.beatId] || o.status === 'approved') {
        statusMap[o.beatId] = o.status;
      }
    });
  res.json(statusMap);
});

app.post('/api/orders', (req, res) => {
  const { beatId, email, transId } = req.body || {};
  const beatIdNum = Number(beatId);

  if (!beatIdNum || !email || !transId) {
    return res.status(400).json({ error: 'beatId, email, and transId are required' });
  }
  if (!isValidEmail(email)) return res.status(400).json({ error: 'Please provide a valid email address' });
  if (String(transId).trim().length < 5) return res.status(400).json({ error: 'Please provide a valid Mobile Money transaction ID' });

  const data = getData();
  const beat = data.beats.find(b => b.id === beatIdNum);
  if (!beat) return res.status(404).json({ error: 'Beat not found' });

  const emailLower = email.toLowerCase().trim();
  const existingPending = data.orders.find(o => o.beatId === beatIdNum && o.email.toLowerCase() === emailLower && o.status === 'pending');
  if (existingPending) return res.status(409).json({ error: 'You already have a pending verification for this beat' });

  const alreadyApproved = data.orders.find(o => o.beatId === beatIdNum && o.email.toLowerCase() === emailLower && o.status === 'approved');
  if (alreadyApproved) return res.status(409).json({ error: 'This beat is already approved for your email — you can download it now' });

  const order = {
    id: Date.now(),
    beatId: beatIdNum,
    beatTitle: beat.title,
    email: email.trim(),
    transId: String(transId).trim(),
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  data.orders.push(order);
  saveData(data);
  res.status(201).json(order);
});

// Only streams/redirects the file if this email has an approved order for this beat.
app.get('/api/download/:beatId', (req, res) => {
  const beatId = Number(req.params.beatId);
  const email = (req.query.email || '').toLowerCase().trim();
  if (!email) return res.status(400).json({ error: 'email is required' });

  const data = getData();
  const beat = data.beats.find(b => b.id === beatId);
  if (!beat) return res.status(404).json({ error: 'Beat not found' });

  const approved = data.orders.some(o => o.beatId === beatId && o.email.toLowerCase() === email && o.status === 'approved');
  if (!approved) return res.status(403).json({ error: 'Payment not approved for this beat yet' });

  if (beat.audioUrl.startsWith('/uploads/')) {
    const filePath = path.join(__dirname, beat.audioUrl);
    const filename = `Geezdrvmz_${beat.title.replace(/\s+/g, '_')}${path.extname(filePath)}`;
    return res.download(filePath, filename);
  }
  // Externally-hosted file — just send the browser there.
  res.redirect(beat.audioUrl);
});

// ===================== ADMIN AUTH =====================

app.post('/api/admin/login', async (req, res) => {
  const { password } = req.body || {};
  if (!ADMIN_PASSWORD_HASH) return res.status(500).json({ error: 'Admin password is not configured on the server yet' });
  if (!password) return res.status(400).json({ error: 'Password required' });

  const match = await bcrypt.compare(password, ADMIN_PASSWORD_HASH);
  if (!match) return res.status(401).json({ error: 'Invalid password' });

  const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token });
});

// ===================== ADMIN: ORDERS =====================

app.get('/api/admin/orders/pending', requireAdmin, (req, res) => {
  res.json(getData().orders.filter(o => o.status === 'pending'));
});

app.post('/api/admin/orders/:id/approve', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const data = getData();
  const order = data.orders.find(o => o.id === id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = 'approved';
  saveData(data);
  res.json(order);
});

app.post('/api/admin/orders/:id/reject', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const data = getData();
  const idx = data.orders.findIndex(o => o.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Order not found' });
  data.orders.splice(idx, 1);
  saveData(data);
  res.json({ ok: true });
});

// ===================== ADMIN: BEATS =====================

app.post('/api/admin/beats', requireAdmin, upload.fields([{ name: 'audio', maxCount: 1 }, { name: 'image', maxCount: 1 }]), (req, res) => {
  const { title, category, price, audioUrl, imageUrl } = req.body || {};
  if (!title || !category || !price) return res.status(400).json({ error: 'title, category, and price are required' });

  const priceNum = parseFloat(price);
  if (!priceNum || priceNum <= 0) return res.status(400).json({ error: 'price must be a positive number' });

  let finalAudioUrl = audioUrl && audioUrl.trim();
  let finalImageUrl = (imageUrl && imageUrl.trim()) || 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=500&q=60';

  if (req.files && req.files.audio) finalAudioUrl = '/uploads/' + req.files.audio[0].filename;
  if (req.files && req.files.image) finalImageUrl = '/uploads/' + req.files.image[0].filename;

  if (!finalAudioUrl) return res.status(400).json({ error: 'Provide an audio file or an audio URL' });

  const data = getData();
  const newBeat = {
    id: Date.now(),
    title: title.trim(),
    category,
    price: priceNum,
    audioUrl: finalAudioUrl,
    imageUrl: finalImageUrl,
    createdAt: new Date().toISOString()
  };
  data.beats.push(newBeat);
  saveData(data);
  res.status(201).json(newBeat);
});

app.delete('/api/admin/beats/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const data = getData();
  const idx = data.beats.findIndex(b => b.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Beat not found' });

  const [removed] = data.beats.splice(idx, 1);
  saveData(data);

  // Best-effort cleanup of a locally-uploaded file (ignore errors — an
  // externally-hosted URL won't match this path and that's fine).
  if (removed && removed.audioUrl && removed.audioUrl.startsWith('/uploads/')) {
    fs.unlink(path.join(__dirname, removed.audioUrl), () => {});
  }
  if (removed && removed.imageUrl && removed.imageUrl.startsWith('/uploads/')) {
    fs.unlink(path.join(__dirname, removed.imageUrl), () => {});
  }

  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Geezdrvmz backend running on http://localhost:${PORT}`));
