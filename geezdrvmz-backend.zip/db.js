// Simple JSON-file data store. Fine for a small beats catalog and
// modest order volume. If this grows into a high-traffic, multi-admin
// operation, swap this module out for a real database (Postgres,
// MySQL, etc.) — the rest of the app only talks to getData()/saveData(),
// so that swap wouldn't require touching server.js's route logic much.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'db.json');

const defaultBeats = [
  { id: 1, title: "Accra Nights", category: "AFRO BEAT", price: 150, audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=500&q=60", createdAt: new Date().toISOString() },
  { id: 2, title: "Trap Royalty", category: "TRAP", price: 200, audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=500&q=60", createdAt: new Date().toISOString() },
  { id: 3, title: "Reggae Vibes", category: "REGGAE", price: 120, audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3", imageUrl: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=500&q=60", createdAt: new Date().toISOString() },
  { id: 4, title: "Boom Bap Classic", category: "HIP HOP", price: 180, audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3", imageUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&w=500&q=60", createdAt: new Date().toISOString() }
];

function ensureDb() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ beats: defaultBeats, orders: [] }, null, 2));
  }
}

function getData() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw);
}

// NOTE: not safe for many concurrent writers hammering the API at the
// same instant (last write wins), but for a small store with an admin
// approving orders occasionally, this is a non-issue.
function saveData(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { getData, saveData };
